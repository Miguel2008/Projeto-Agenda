package ConnectionFactory;

public interface AgendaDAO {

}
