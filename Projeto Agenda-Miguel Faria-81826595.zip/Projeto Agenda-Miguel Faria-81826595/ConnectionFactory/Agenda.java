package ConnectionFactory;

public class Agenda {

	public static void main(String[] args) {
		Agenda agenda = new Agenda();
	}
}
